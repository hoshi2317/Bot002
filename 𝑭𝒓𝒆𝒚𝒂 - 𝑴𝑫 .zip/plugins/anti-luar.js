const fetch = (await import('node-fetch'))
let handler = m => m

handler.before = async function (m) {
   let chat = global.db.data.chats[m.chat]
    if (chat.antiBuleAll && !chat.isBanned ) {
        if (/^.*false|disnable|(turn)?off|0/i.test(m.text)) return
        if (!m.text) return
   if (m.sender.startsWith('212' || '212')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   
   if (m.sender.startsWith('92' || '92')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('1' || '1')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('91' || '91')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('90' || '90')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('7' || '7')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('55' || '55')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('44' || '44')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('94' || '94')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('202' || '202')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('45' || '45')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }

   if (m.sender.startsWith('265' || '265')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('84' || '84')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('27' || '27')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('48' || '48')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('351' || '351')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('267' || '267')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('225' || '225')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('233' || '233')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('234' || '234')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('250' || '250')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('265' || '265')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('967' || '967')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
   if (m.sender.startsWith('976' || '976')) {
   	global.db.data.users[m.sender].banned = true
conn.reply(m.chat, asing, m)
this.groupParticipantsUpdate(m.chat, [m.sender], "remove")
this.updateBlockStatus(m.sender, 'block')
   }
  return true 
 }
}
export default handler